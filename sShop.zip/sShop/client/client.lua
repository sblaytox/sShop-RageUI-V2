Citizen.CreateThread(function()
   while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(5000)
    end
end)

local mainMenu = RageUI.CreateMenu("Supérette", "Menu") 
local Nourriture = RageUI.CreateSubMenu(mainMenu, "Supérette", "Alimentation") 
local Boisson = RageUI.CreateSubMenu(mainMenu, "Supérette", "Boisson") 
local open = false

mainMenu.Display.Glare = false 
Nourriture.Display.Glare = false 
Boisson.Display.Glare = false 

mainMenu.Closed = function() open = false end

function shops() 
    if open then 
        open = false 
            RageUI.Visible(mainMenu, false) 
        return 
    else 
        open = true 
            RageUI.Visible(mainMenu, true)
        Citizen.CreateThread(function()
            while open do 
                RageUI.IsVisible(mainMenu, function()
                    RageUI.Separator("~g~↓          ~o~Gestion Nourriture         ~g~↓")
                    RageUI.Button("🍔 I ~b~Alimentation", nil, {RightLabel = "~g~→→"}, true, {}, Nourriture)
                    RageUI.Button("🍾 I ~b~Boissons", nil, {RightLabel = "~g~→→"}, true, {}, Boisson) 
                    RageUI.Separator("~g~🍅          ~o~Supérette I L.T.D         ~g~🍅")
                end)
                RageUI.IsVisible(Nourriture, function()
                    RageUI.Separator("~g~↓          ~o~Nourriture Saine         ~g~↓")
                    RageUI.Button("🍞 I Pain", "                 📋 - Bienvenue au L.T.D - 📋", {RightLabel = config.prixitemNourriture1}, true, { 
                        onSelected = function() 
                            TriggerServerEvent('sblaytox:achatPain') 
                        end
                    })
                    RageUI.Button("🥖 I Sandwich", "                 📋 - Bienvenue au L.T.D - 📋", {RightLabel = config.prixitemNourriture2}, true, { 
                        onSelected = function() 
                            TriggerServerEvent('sblaytox:achatSandwich') 
                        end
                    })
                    RageUI.Separator("~g~↓          ~o~Friandise         ~g~↓")
                    RageUI.Button("🍫 I Chocolat", "                 📋 - Bienvenue au L.T.D - 📋", {RightLabel = config.prixitemNourriture3}, true, { 
                        onSelected = function() 
                            TriggerServerEvent('sblaytox:achatChocolat')
                        end
                    })
                end)
                RageUI.IsVisible(Boisson, function()
                    RageUI.Separator("~g~↓          ~o~Boisson Saine         ~g~↓")
                    RageUI.Button("💧 I Eau", "                 📋 - Bienvenue au L.T.D - 📋", {RightLabel = config.prixitemBoisson1}, true, {
                        onSelected = function() 
                            TriggerServerEvent('sblaytox:achatEau') 
                        end
                    })
                    RageUI.Separator("~g~↓          ~o~Boisson Alcoolisée         ~g~↓")
                    RageUI.Button("🍾 I Mojito", "                 📋 - Bienvenue au L.T.D - 📋", {RightLabel = config.prixitemBoisson2}, true, { 
                        onSelected = function()
                            TriggerServerEvent('sblaytox:achatMojito')
                        end
                    })
                    RageUI.Button("🍷 I Whisky", "                 📋 - Bienvenue au L.T.D - 📋", {RightLabel = config.prixitemBoisson3}, true, { 
                        onSelected = function() 
                            TriggerServerEvent('sblaytox:achatWhisky') 
                        end
                    })
                    RageUI.Separator("~g~↓          ~o~Soft         ~g~↓")
                    RageUI.Button("🍊 I Fanta", "                 📋 - Bienvenue au L.T.D - 📋", {RightLabel = config.prixitemBoisson5}, true, {
                        onSelected = function() 
                            TriggerServerEvent('sblaytox:achatFanta') 
                        end
                    })
                end)
            Wait(0)
            end
        end)
    end
end

Citizen.CreateThread(function()
    while true do
      local wait = 900
        for k,v in pairs(Config.position) do
            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, v.x, v.y, v.z)
            if dist <= 4 then 
                wait = 1       
                DrawMarker(config.markertype, v.x, v.y, v.z, 0.0, 0.0, 0.0, -180.0,0.0,0.0, 0.5, 0.5, 0.5, config.red, config.green, config.blue, config.opacity, false, true, p19, false)  
            end
            if dist <= 1.0 then
                wait = 1
                Visual.Subtitle("Appuyez sur ~r~[E]~w~ pour intéragir", 1)
                ESX.ShowHelpNotification("Appuyez sur ~INPUT_CONTEXT~ pour intéragir") 
                if IsControlJustPressed(1,51) then
                    shops() 
                end
            end 
        end
    Citizen.Wait(wait)
    end
end)


--------------------------------------------- Création Blips ---------------------------------------------

Citizen.CreateThread(function() 
    for k, v in pairs(Config.position) do 
        local blip = AddBlipForCoord(v.x, v.y, v.z) 
                     SetBlipSprite  (blip, config.blipsprite) 
                     SetBlipDisplay (blip, config.blipdisplay) 
                     SetBlipScale   (blip, config.blipscale) 
                     SetBlipColour  (blip, config.blipcolour) 
                     SetBlipAsShortRange(blip, true) 
                     BeginTextCommandSetBlipName('STRING') 
                     AddTextComponentSubstringPlayerName(config.blipname) 
                     EndTextCommandSetBlipName(blip) 
    end 
end)

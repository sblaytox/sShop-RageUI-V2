INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES

-- Nourriture

('bread', 'Pain', 1, 0, 1),
('sandwich', 'Sandwich', 1, 0, 1),
('chocolate', 'Chocolat', 1, 0, 1),

-- Boisson

('water', 'Eau', 1, 0, 1),
('coke', 'Coca', 1, 0, 1),
('fanta', 'Fanta', 1, 0, 1),
('whisky', 'Whisky', 1, 0, 1),
('mojito', 'Mojito', 1, 0, 1);
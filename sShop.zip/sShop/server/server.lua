ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
  

RegisterNetEvent('sblaytox:achatEau') 
AddEventHandler('sblaytox:achatEau', function() 
  local joueur = ESX.GetPlayerFromId(source)  
  local prix = 12 
  local argent = joueur.getMoney()
    if argent >= prix then 
      joueur.removeMoney(prix) 
      joueur.addInventoryItem('water', 1) 
      TriggerClientEvent('esx:showNotification', source, "Achat effectué !") 
    else 
      TriggerClientEvent('esx:showNotification', source, "Vous n'avez pas assez d\'argent") 
    end
end)


RegisterNetEvent('sblaytox:achatWhisky') 
AddEventHandler('sblaytox:achatWhisky', function() 
  local joueur = ESX.GetPlayerFromId(source)  
  local prix = 36 
  local argent = joueur.getMoney()
    if argent >= prix then 
      joueur.removeMoney(prix) 
      joueur.addInventoryItem('whisky', 1) 
      TriggerClientEvent('esx:showNotification', source, "Achat effectué !") 
    else 
      TriggerClientEvent('esx:showNotification', source, "Vous n'avez pas assez d\'argent") 
    end
end)


RegisterNetEvent('sblaytox:achatMojito') 
AddEventHandler('sblaytox:achatMojito', function() 
  local joueur = ESX.GetPlayerFromId(source)  
  local prix = 24 
  local argent = joueur.getMoney()
    if argent >= prix then 
      joueur.removeMoney(prix) 
      joueur.addInventoryItem('mojito', 1)
      TriggerClientEvent('esx:showNotification', source, "Achat effectué !")
    else 
      TriggerClientEvent('esx:showNotification', source, "Vous n'avez pas assez d\'argent") 
    end
end)


RegisterNetEvent('sblaytox:achatFanta') 
AddEventHandler('sblaytox:achatFanta', function() 
  local joueur = ESX.GetPlayerFromId(source)  
  local prix = 48
  local argent = joueur.getMoney()
    if argent >= prix then 
      joueur.removeMoney(prix) 
      joueur.addInventoryItem('fanta', 1)
      TriggerClientEvent('esx:showNotification', source, "Achat effectué !")
    else 
      TriggerClientEvent('esx:showNotification', source, "Vous n'avez pas assez d\'argent") 
    end
end)


RegisterNetEvent('sblaytox:achatPain')
AddEventHandler('sblaytox:achatPain', function() 
  local joueur = ESX.GetPlayerFromId(source)  
  local prix = 16 
  local argent = joueur.getMoney()
    if argent >= prix then 
      joueur.removeMoney(prix) 
      joueur.addInventoryItem('bread', 1) 
      TriggerClientEvent('esx:showNotification', source, "Achat effectué !") 
    else 
      TriggerClientEvent('esx:showNotification', source, "Vous n'avez pas assez d\'argent") 
    end
end)

RegisterNetEvent('sblaytox:achatSandwich') 
AddEventHandler('sblaytox:achatSandwich', function() 
  local joueur = ESX.GetPlayerFromId(source)  
  local prix = 32 
  local argent = joueur.getMoney()
    if argent >= prix then 
      joueur.removeMoney(prix) 
      joueur.addInventoryItem('sandwich', 1) 
      TriggerClientEvent('esx:showNotification', source, "Achat effectué !") 
    else 
      TriggerClientEvent('esx:showNotification', source, "Vous n'avez pas assez d\'argent") 
    end
end)


RegisterNetEvent('sblaytox:achatChocolat') 
AddEventHandler('sblaytox:achatChocolat', function() 
  local joueur = ESX.GetPlayerFromId(source)  
  local prix = 48
  local argent = joueur.getMoney()
    if argent >= prix then 
      joueur.removeMoney(prix) 
      joueur.addInventoryItem('chocolate', 1) 
      TriggerClientEvent('esx:showNotification', source, "Achat effectué !") 
    else 
      TriggerClientEvent('esx:showNotification', source, "Vous n'avez pas assez d\'argent") 
    end
end)
